<?php session_start();
if(empty($_SESSION['nama'])){ ?>
    <script> window.location.href='../index.php' </script>
<?php }
$nama = $_SESSION['nama'];
if($_SESSION['hak'] == 'admin'){}else{ ?> <script> alert('Anda Bukan Admin!'); window.location.href='../logout.php' </script> <?php } 
include "../conf/connection.php";
 ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Barley Bakery and Cake </title>
    <link href="../assets/ico/barley.jpeg" rel="shorcut icon">
    <!-- Bootstrap core CSS -->
    <link href="../assets/css/bootstrap.css" rel="stylesheet">
    <!-- Datatables core CSS -->
    <link href="../assets/css/datatables.css" rel="stylesheet">
     <!-- custom CSS here -->
    <link href="../assets/css/style.css" rel="stylesheet" />
</head>
<body>
	<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <span class="navbar-brand">Barley Bakery and Cake<span class="glyphicon glyphicon-shopping-cart"></span></span>
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li><a href="home.php">Beranda</a></li>
                    <li><a href="pengguna.php">Pengguna</a></li>
                    <li><a href="kategori.php">Kategori</a></li>
                    <li class="active"><a href="barang.php">Barang</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="profil.php"><?php echo ucwords("$nama"); ?></a></li>
                    <li><a href="../logout.php">Keluar</a></li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
<div class="container">
   <br><br>
   <div class="page-header">
   	<h2> Data Barang </h2>
   </div>
   <table id="tables" class="table table-responsive table-bordered table-striped">
   	<thead>
   		<tr>
        <th style="text-align: center;"> Nama Barang </th>
        <th style="text-align: center;"> Harga </th>
   			<th style="text-align: center;"> Stok </th>
   			<th style="text-align: center;"> Kategori </th>
        <th style="text-align: center;"> Aksi </th>
   		</tr>
   	</thead>
   	<?php
   		$sql = "select * from kategori inner join barang on kategori.id_kategori = barang.id_kategori";
   		$query = mysqli_query($connect, $sql);
      $no = 1;
   		while ($data = mysqli_fetch_array($query)){ ?>
   			<tr>
          <td><?php echo ucwords("$data[nama_barang]"); ?></td>
          <td>Rp. <?php echo number_format($data['harga']); ?></td>
          <td><?php echo ucwords("$data[stok]"); ?></td>
   				<td><?php echo ucwords("$data[kategori]"); ?></td>
          <td><center><button class="btn btn-success" data-toggle="modal" data-target="#EditBarang<?php echo $no; ?>">Edit</button>
            <a href="hapus-barang.php?id_barang=<?php echo "$data[id_barang]"; ?>" onclick='return confirm("Anda Yakin?")' class="btn btn-danger">Hapus</a></center></td>
  			</tr>
           <!-- modal edit -->
          <div id="EditBarang<?php echo $no; ?>" class="modal fade" role="dialog">
             <div class="modal-dialog">
            <!-- konten modal-->
            <div class="modal-content">
              <!-- heading modal -->
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Edit Barang</h4>
              </div>
              <!-- body modal -->
              <div class="modal-body">
                <form action="edit-barang.php" method="POST" enctype="multipart/form-data">
                  <input type="text" name="nama_barang" class="form-control" maxlength="35" placeholder="Masukkan Nama Barang.." value="<?php echo "$data[nama_barang]"; ?>" required/><br>
                  <input type="number" name="harga" class="form-control" maxlength="35" placeholder="Masukkan Harga Barang.." value="<?php echo "$data[harga]"; ?>" required/><br>
                  <input type="number" name="stok" class="form-control" maxlength="35" placeholder="Masukkan Stok Barang.." value="<?php echo "$data[stok]"; ?>" required/><br>
                  <select name="id_kategori" class="form-control">
                    <option value="<?php echo "$data[id_kategori]"; ?>"><?php echo "$data[kategori]"; ?></option>
                    <?php
                      $d = "select * from kategori where not id_kategori='".$data['id_kategori']."'";
                      $e = mysqli_query($connect, $d);
                      while ($f = mysqli_fetch_array($e)){ ?>
                        <option value="<?php echo "$f[id_kategori]"; ?>"><?php echo "$f[kategori]"; ?></option>
                      <?php }
                    ?>
                  </select><br>
                  <input type="hidden" name="id_barang" value="<?php echo "$data[id_barang]"; ?>">
                  <input type="hidden" name="img" value="<?php echo "$data[gambar]"; ?>">
                  <center><img src="../images/product/<?php echo "$data[gambar]"; ?>" width="20%" height="20%"><br></center>
                  <input type="file" name="foto" class="form-control">
              </div>
              <!-- footer modal -->
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
                <input type="submit" class="btn btn-primary" value="OK">
              </form>
              </div>
            </div>
   		<?php $no++; }
   	?>
   </table>
   <center><button class="btn btn-primary" data-toggle="modal" data-target="#TambahBarang">Tambah Barang</button>
 </div>
   <!-- modal tambah -->
    <div id="TambahBarang" class="modal fade" role="dialog">
       <div class="modal-dialog">
      <!-- konten modal-->
      <div class="modal-content">
        <!-- heading modal -->
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Tambah Barang</h4>
        </div>
        <!-- body modal -->
        <div class="modal-body">
          <form action="tambah-barang.php" method="POST" enctype="multipart/form-data">
            <input type="text" name="nama_barang" class="form-control" maxlength="35" placeholder="Masukkan Nama Barang.." required/><br>
            <input type="number" name="harga" class="form-control" maxlength="35" placeholder="Masukkan Harga Barang.." required/><br>
            <input type="number" name="stok" class="form-control" maxlength="35" placeholder="Masukkan Stok Barang.." required/><br>
            <select name="id_kategori" class="form-control">
              <?php
                $a = "select * from kategori";
                $b = mysqli_query($connect, $a);
                while ($c = mysqli_fetch_array($b)){ ?>
                  <option value="<?php echo "$c[id_kategori]"; ?>"><?php echo "$c[kategori]"; ?></option>
                <?php }
              ?>
            </select><br>
            <input type="file" name="gambar" class="form-control" required/>
        </div>
        <!-- footer modal -->
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
          <input type="submit" class="btn btn-primary" value="OK">
        </form>
        </div>
      </div>
    </div>
  </div>

  <center><a href="cetak-barang.php" class="btn btn-success" target="_BLANK">Cetak</a></center>

	<!--Footer -->
    <div class="col-md-12 end-box ">
         &copy; 2022 | All Rights Reserved | Adam - Barley Bakery and Cake
    </div>
    <!-- /.col -->
    <!--Footer end -->
    <!--jQUERY FILES-->
    <script src="../assets/js/jquery-1.10.2.js"></script>
    <!--BOOTSTRAP  FILES-->
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/datatables.js"></script>
    <script>
        $(document).ready(function () {
          $('#tables').DataTable();
          $('.dataTables_length').addClass('bs-select');
        });
    </script>
</body>
</html>